import pytest


@pytest.mark.smoke
def buildCheck_android(initiateBuild):
    print("Test Case 0.1: Done")


def testCase_1_1(initiateBuild):
    print("Test Case 1.1: Done")


def testCase_1_2():
    print("Test Case 1.2: Done")


def testCase_1_3():
    print("Test Case 1.3: done")

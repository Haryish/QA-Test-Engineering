class BaseClass:
    pass
